# [www.developerlibs.com](https://www.developerlibs.com)

Flutter – Login and registration authentication with Firebase. [Read me here](https://www.developerlibs.com/2018/10/flutter-login-registration-authentication-firebase.html)

[YouTube](https://youtu.be/dt4HlORuT7Q) ,
[Facebook](https://www.facebook.com/developerlibs), 
[G+](https://plus.google.com/109457600203481575432),
[Instagram](https://www.instagram.com/developerlibs/), 
[Twitter](https://twitter.com/LibsDeveloper)

[Join us on Slack](https://join.slack.com/t/developerlibs/shared_invite/enQtNDU1NzQzNTM5MDYwLTk0Mjc2MWQwNGExNDdiZWQ5MzJlYTVhZGQzMTRiOTcwODVmOGNmMWM5NTZkYWIxNDExNWM0NWMzZjBhODRmNDg)

![ScreenShot](https://github.com/DeveloperLibs/flutter_firebase_auth/blob/master/screen/firebase_auth_gif.gif)

