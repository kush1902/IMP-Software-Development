abstract class BaseViewContract  {
  void showLoader();

  void closeLoader();

  void showAlert(String msg);

}